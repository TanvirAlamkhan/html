<!DOCTYPE html>
<html>
<head>
 <title>Profile</title>
</head>
<body>
 <h1>Profile</h1>
 <form id="display" method="post" action="display_info.php">
 <table>
 <tr>
 <td>
 <fieldset style="width=50%">
 <legend>General Information</legend>
 <img src="lab1.jpg" alt="Admin" length="180px" width="120px" align="right">
 <?php
 echo "First Name: " . (isset($_POST['firstName']) ? $_POST['firstName'] : "");
 echo "<br><br>";
 echo "Last Name: " . (isset($_POST['lastName']) ? $_POST['lastName'] : "");
 echo "<br><br>";
 echo "Father's Name: " . (isset($_POST['fatherName']) ? $_POST['fatherName'] : "");
 echo "<br><br>";
 echo "Mother's Name: " . (isset($_POST['motherName']) ? $_POST['motherName'] : "");
 echo "<br><br>";
 echo "Blood Group: " . (isset($_POST['blood']) ? $_POST['blood'] : "");
 echo "<br><br>";
 echo "Gender: " . (isset($_POST['gender']) ? $_POST['gender'] : "");
 echo "<br><br>";
 echo "Religion: " . (isset($_POST['Religion']) ? $_POST['Religion'] : "");
 echo "<br><br>";
 ?>
 </fieldset>
 </td>
 <td>
 <fieldset  style="width=50%">
 <legend>Contact Information</legend>
 <?php
 echo "Email: " . (isset($_POST['email']) ? $_POST['email'] : "") . (isset($_POST['emailDomain']) ? $_POST['emailDomain'] : "");
 echo "<br><br>";
 echo "Phone Number: " . (isset($_POST['phoneCountryCode']) ? $_POST['phoneCountryCode'] : "") . (isset($_POST['phoneNumber']) ? $_POST['phoneNumber'] : "");
 echo "<br><br>";
 echo "Website: " . (isset($_POST['urlPrefix']) ? $_POST['urlPrefix'] : "") . (isset($_POST['url']) ? $_POST['url'] : "");
 echo "<br><br>";
 echo "Address: " . (isset($_POST['personalAddress']) ? $_POST['personalAddress'] : "") . (isset($_POST['city']) ? ", " . $_POST['city'] : "") . (isset($_POST['zip']) ? ", " . $_POST['zip'] : "") . (isset($_POST['countryN']) ? ", " . $_POST['countryN'] : "");
 ?>
 </fieldset>
 </td>
 </tr>
 </table>
 </form>
</body>
</html>